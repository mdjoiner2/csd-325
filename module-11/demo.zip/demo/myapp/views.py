from django.http import HttpResponse

def home(request):
    return HttpResponse("Joiner says Hello!")
